module KernelLib = {

  let rbf (x: [n][d]f32) (y: [m][d]f32) (sigma: f32) : [n][m]f32 =
    map (\xi ->
      map (\yi ->
        let dist_sq = reduce (+) 0.0 (map2 (\a b -> (a-b)*(a-b)) xi yi)
        in exp(-dist_sq / (2.0*sigma*sigma))
      ) y
    ) x

  let linear (x: [n][d]f32) (y: [m][d]f32) : [n][m]f32 =
    map (\xi ->
      map (\yi ->
        reduce (+) 0.0 (map2 (*) xi yi)
      ) y
    ) x

  let polynomial (x: [n][d]f32) (y: [m][d]f32)
                 (c: f32) (p: i32) : [n][m]f32 =
    map (\xi ->
      map (\yi ->
        let dot = reduce (+) 0.0 (map2 (*) xi yi)
        in (dot + c) ** f32.p
      ) y
    ) x

  entry dispatch_kernel
        (kind: i32)
        (x: [] [] f32)
        (y: [] [] f32)
        (sigma: f32)
        (c: f32)
        (p: i32)
        : [][]f32 =
    if kind == 0 then rbf x y sigma
    else if kind == 1 then linear x y
    else if kind == 2 then polynomial x y c p
    else replicate (length x) (replicate (length y) 0.0)
}